def get_values(LOD, key):
  ret_val = []
  list_1 = []
  for dic in LOD:
    for i in dic:
      if i == key:
        list_1.append(dic[i])

  for i in list_1:
    if i not in ret_val:
      ret_val.append(i)
  return ret_val 


def break_out(LOD, key):
  ret_val = {}
  for dic in  LOD:
    for i in dic:
      if i == key:
        ret_val[dic[i]] = []
  
  for dic in  LOD:
    for i in dic:
      if i == key:
        ret_val[dic[i]].append(dic)
  
  return ret_val


def sum_values(LOD, key):
  sum = 0
  for dic in LOD:
    for i in dic:
      if i == key:
        sum += dic[i]
  return sum


def get_year(LOD, set = 'project_completion_date'):
  ret_val  = []
  for dic in LOD:
    for i in dic: 
      if i == set:
        val = dic[set]
        year = val[0]+val[1]+val[2]+val[3]
        ret_val.append(year)
  return ret_val


def sum_values_by_year(LOD, key):
  set = 'project_completion_date'
  years = get_year(LOD)
  ret_val = {}

  for n in years:
    ret_val[n] = 0

  for dic in LOD:
    for i in dic:
      if i == set:
        val = dic[set]
        year = val[0]+val[1]+val[2]+val[3]
        ret_val[year] += int(dic[key])
  return ret_val